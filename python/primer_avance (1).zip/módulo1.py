import Database

def leer(con):

    cursorObj = con.cursor()

    cursorObj.execute('SELECT * FROM mesas')

    rows = cursorObj.fetchall()

    for row in rows:

        print(row)

leer(Database.con)
